

const fs = require('fs');
const path = require('path');

let args = process.argv.slice(2);

function getRowsFromReadFile({
    readFilePath,
}) {
    let readFileArray = fs.readFileSync(readFilePath)
        .toString()
        .split('\n')
        .map(m => m.replace('\r', ''));
    let headers = readFileArray[0].split(',').filter(f => f.length > 0);
    console.log('HEADERS:\n', headers, '\n');
    let content = readFileArray.slice(1);
    let rows = content.map(stringRow => {
        let vals = stringRow.split(',');
        let tempObj = {};
        let findAndReplacers = [];

        headers.forEach((hdr, hdrIdx) => {
            if (/find/i.test(hdr)) {
                if (vals[hdrIdx].length > 0) {
                    findAndReplacers.push({
                        find: vals[hdrIdx],
                        replace: vals[hdrIdx + 1],
                    });
                };
                if (findAndReplacers.length > 0) {
                    tempObj['findAndReplacers'] = findAndReplacers;
                }
            }

            else

                if (/replace/i.test(hdr)) {
                    let letsDo = 'nothing';
                }

                else
                    if (vals[hdrIdx] && vals[hdrIdx].length > 0) {
                        tempObj[hdr] = vals[hdrIdx];
                    }
        });

        return tempObj;
    });
    console.log(
        'EXAMPLE CSV ROW CONERTED TO JS OBJECT:\n________\n',
        '\nCSV TEXT:\n',
        content[0],
        '\n\n--> OBJECT:\n',
        rows[0],
        '\n'
    );
    // let rowsAggregate = [];
    // rows.forEach(row => {
    //     let findAndReplaces = [];
    //     let findHdrs = [];
    //     headers.forEach((hdr,hdrIdx)=>{
    //         if (/find/i.test(hdr)) {
    //             findAndReplaces.push({
    //                 find:row
    //             })
    //         }
    //     })
    // });
    // console.log(rows)''
    // rows.forEach(row => {
    //     let filteredFileProps = [
    //         row.new_file_1,
    //         row.new_file_2,
    //         row.new_file_3,
    //     ].filter(f => f);
    //     if (filteredFileProps.length < 1) return null;
    //     filteredFileProps.forEach(eachFile => {
    //         rowsAggregate.push({
    //             ...row,
    //             new_file: eachFile,
    //         })
    //     })
    // });
    // console.log(rowsAggregate)
    // return rowsAggregate;
    let filteredRow = rows.filter(f => Object.keys(f).length > 0)
    return filteredRow;
};

const argsConfig = {
    csvMatcher: {
        argString: '--csv_matcher',
    },
    outDir: {
        argString: '--out_dir',
    },
    prod: {
        argString: '--prod',
    },
};

let csvMatcher = args.includes(argsConfig.csvMatcher.argString)
    ? new RegExp(
        args[args.indexOf(argsConfig.csvMatcher.argString) + 1]
    ) : /Replace/;
let outDirName = args.includes(argsConfig.outDir.argString)
    ? args[args.indexOf(argsConfig.outDir.argString) + 1]
    : '_OUT';
let prod = args.includes(argsConfig.prod.argString)
    ? true
    : false;

console.log('FINDING CSV BY MATCHER:\n', csvMatcher, '\n');

let readFilePath =
    fs.readdirSync(__dirname)
        .filter(f => csvMatcher.test(f) && /\.csv/i.test(f))
    [0];

console.log('MATCHED TO CSV:', readFilePath, '\n');

let rows = getRowsFromReadFile({ readFilePath: readFilePath })

console.log('# ROWS IN CSV:\n', rows.length, '\n');

rows.forEach(row => {
    if (row => !row.new_file || typeof row.new_file === 'undefined') {
        console.log('\n\n***\n***\nERROR:\n\nMUST PROVIDE COLUMN new_file IN CSV.  THIS IS FILENAME FOR CREATED FILE.\n');
        console.log('GRABBING DATA FROM CSV: ', readFilePath, '\n');
        console.log('ROW = ', row)
        console.log('***\n***\n\n\n');
        // console.log(fs.readFileSync(readFilePath).toString());
        return null;
    };
});
if (rows.some(row => !row.new_file || typeof row.new_file === 'undefined')) {
    return null;
}
rows.forEach(row => {

    if (row => !row.original_file || typeof row.original_file === 'undefined') {
        console.log('\n\n***\n***\nERROR:\n\nMUST PROVIDE COLUMN original_file IN CSV.  THIS IS FILENAME USED TO GRAB THE "TEMPLATE" SVG.\n');
        console.log('GRABBING DATA FROM CSV: ', readFilePath, '\n');
        console.log('ROW = ', row)
        console.log('***\n***\n\n\n');
        // console.log(fs.readFileSync(readFilePath).toString());
        return null;
    };
});
if (rows.some(row => !row.new_file || typeof row.new_file === 'undefined')) {
    return null;
};


let actionRows = rows.map((row, rowIdx) => {

    let files = fs.readdirSync(__dirname)
        .filter(f => /\.svg/i.test(f))
        .map(m => path.join(__dirname, m))
    for (let i = 0; i < files.length; i++) {
        let file = files[i];
        /* CANT USE REGEX BC OF THE PARENTHESES AND DOTS IN FILE NAME  cant do -> // if (matcher.test(file)) { */
        if (file.indexOf(row.original_file) > -1) {
            console.log(outDirName, row.new_file)
            return {
                oldFilePath: file,
                newFilePath: path.join(__dirname, outDirName, row.new_file),
                newFileName: row.new_file,
                // find: row.find,
                // replacement: row.replace,
                findAndReplacers: row.findAndReplacers,
                dir: __dirname,
            }
        };
    };
    return null;
})
    .filter(f => f);
if (actionRows.length < 1) { return null; };


console.log('\nEXAMPLE ACTION ROW:\n', actionRows);
console.log('\nEXAMPLE ACTION ROW:\n', actionRows[0]);

let outDir = path.join(__dirname, outDirName);
console.log('\nMAKING OUT DIRECTORY:\n', outDir, '\n');
fs.mkdirSync(outDir, { recursive: true });

let replaced = actionRows.map(actionRow => {

    let { findAndReplacers, oldFilePath, newFileName, find, replacement, dir } = actionRow;
    let fileContents = fs.readFileSync(oldFilePath).toString();

    let mutableFileContents = fileContents;
    findAndReplacers.forEach(({ find, replace }) => {
        let findRegExp = new RegExp(find, 'ig');
        mutableFileContents = mutableFileContents.replace(findRegExp, replace)
    })
    // let matcher = new RegExp(find, 'ig');
    // let found = [...fileContents.matchAll(matcher)].map(m => m[0])
    // console.log('found', found, 'found');
    let newFilename = path.join(outDir, newFileName);
    fs.writeFileSync(
        newFilename,
        mutableFileContents,
        // fileContents.replace(matcher, replacement)
    );
    return newFilename;
})

console.log('\nREPLACED\n', replaced, '\nREPLACED\n')



// console.log(rows, rows.length)


const DOCUMENTATION = `/**
 * PARAMETERS
 * __________
 * 
 * --csv_matcher
 *      - default: Replace
 *      - required: false
 *      - A continuous string (endss at first white space)
 *        from which a new regular expression is created and 
 *        used to find a CSV file in the containing directory
 *      - example - If you want use a CSV with filename "finreplac123.csv",
 *        you could run the following command.
 *        $ node findAndReplaceSvg --csv_matcher finrep
 * 
 * --out_dir
 *      - default: _OUT
 *      - required: false
 *      - Name of output directory, which will be created in containing directory.
 *      - example - To generate output files in "/SVGS_OUTPUT/", run the follwing command.
 *        $ node findAndReplaceSvg --out_dir SVGS_OUTPUT
 * 
 * --prod
 *      - Remove this documentation from console.log output
 *      - example - Run the follwing command.
 *        $ node findAndReplaceSvg --prod
 * 
 * 
 *  CSV SPECIFICATIONS:
 *          
 *      REQUIRED COLUMNS (COLUMN HEADERS MUST MATCH)
 * 
 *          - new_file
 *          - original_file
 *          - find1
 *          - replace1
 *      
 *          - *OPTIONAL find2
 *          - *OPTIONAL replace2
 *          - *OPTIONAL find3
 *          - *OPTIONAL replace3
 */`;
if (!prod) {
    console.log(DOCUMENTATION)
}
