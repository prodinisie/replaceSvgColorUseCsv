const fs = require('fs');
const path = require('path');

let csvAccumulation = 'file,fill2,fill\n';;

fs.readdirSync(__dirname)
    .filter(f => /\.svg/i.test(f))
    .map(m => path.join(__dirname, m))
    .forEach(file => {
        let hashMatch = /\#[a-zA-Z0-9]{3,6}/g;
        let matchies = [...fs.readFileSync(file).toString().matchAll(hashMatch)].map(m => m[0])
        console.log(matchies);
        csvAccumulation += file + ',' + matchies + '\n'
    });

if (process.argv[2] === '--csv') {
    fs.writeFileSync(
        path.join(__dirname, 'fillsFromSvgs.csv'),
        csvAccumulation,
    )
}

console.log(process.argv);
